"""
Determine the sensor health evaluation window.
"""

from dataclasses import dataclass


@dataclass(slots=True)
class SensorHealthWindow:
    start_us: int
    end_us: int


class SensorHealthWindowDetector:

    DEFAULT_THRESHOLD = 5.0

    def detect(self, flight):

        gps = flight.get("GPS")

        if gps.empty:
            raise ValueError("No GPS data available.")

        threshold = self._threshold(flight)

        flying = gps[gps["Spd"] > threshold]

        if flying.empty:
            raise ValueError("No in-flight GPS data found.")

        return SensorHealthWindow(
            start_us=int(flying.iloc[0]["TimeUS"]),
            end_us=int(flying.iloc[-1]["TimeUS"]),
        )

    def _threshold(self, flight):

        stall = flight.parameters.get("AIRSPEED_STALL")

        if stall is None:
            return self.DEFAULT_THRESHOLD

        return max(stall * 0.5, self.DEFAULT_THRESHOLD)
