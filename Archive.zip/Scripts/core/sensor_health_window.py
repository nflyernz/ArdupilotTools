"""
Determine the sensor health evaluation window.

A SensorHealthWindow defines the period during which the aircraft
is considered to be in sustained flight and sensor health checks
are meaningful.

The detector is based solely on GPS ground speed and is independent
of flight mode, mission state and landing detection.

The current implementation detects a single flight within a log.
Support for multiple flights will be added by a higher-level flight
window detector, allowing one SensorHealthWindow to be created for
each flight.
"""

from dataclasses import dataclass


@dataclass(slots=True)
class SensorHealthWindow:
    """
    Time interval over which sensor validation should be performed.
    """

    start_us: int
    end_us: int


class SensorHealthWindowDetector:
    """
    Detect the sensor health window for a single flight.

    Flight is considered to begin once GPS ground speed exceeds the
    flight threshold for a minimum number of consecutive samples.

    Likewise, the end of flight is determined by the last sustained
    period above the threshold. A small amount of time is trimmed
    from each end to remove transient behaviour during takeoff and
    landing.
    """

    DEFAULT_THRESHOLD = 5.0
    MIN_SAMPLES = 5
    TRIM_US = 2_000_000      # 2 seconds

    def detect(self, flight):

        gps = flight.get("GPS")

        if gps.empty:
            raise ValueError("No GPS data available.")

        threshold = max(
            self.DEFAULT_THRESHOLD,
            0.5 * flight.param(
                "AIRSPEED_STALL",
                self.DEFAULT_THRESHOLD * 2,
            ),
        )

        flying = gps["Spd"] > threshold

        start = self._find_start(flying)

        if start is None:
            raise ValueError(
                "Unable to determine sensor health window."
            )

        end = self._find_end(flying)

        start_us = int(gps.iloc[start]["TimeUS"]) + self.TRIM_US
        end_us = int(gps.iloc[end]["TimeUS"]) - self.TRIM_US

        if start_us >= end_us:
            raise ValueError(
                "Sensor health window is too short."
            )

        return SensorHealthWindow(
            start_us=start_us,
            end_us=end_us,
        )

    def _find_start(self, flying):

        count = 0

        for index, state in enumerate(flying):

            if state:
                count += 1

                if count >= self.MIN_SAMPLES:
                    return index - self.MIN_SAMPLES + 1
            else:
                count = 0

        return None

    def _find_end(self, flying):

        count = 0

        for index in range(len(flying) - 1, -1, -1):

            if flying.iloc[index]:
                count += 1

                if count >= self.MIN_SAMPLES:
                    return index + self.MIN_SAMPLES - 1
            else:
                count = 0

        return None